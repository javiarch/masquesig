var map = L.map( 'map', {
    center: [30, -100],
    minZoom: 2,
    zoom: 5,
    zoomControl: false
});

L.tileLayer( 'road/{z}/{x}/{y}.png', {
    attribution: 'Mapbox',
}).addTo( map );
