// See post: http://asmaloney.com/2014/01/code/creating-an-interactive-map-with-leaflet-and-openstreetmap/

var bounds = L.latLngBounds([30, -10], [60, 75]);

var map = L.map( 'map', {
    center: [50, 10],
    minZoom: 2,
    zoom: 5,
    zoomControl: false,
    maxBounds: bounds
});


// Example: convexHull
var convexHull = turf.convex(geodata);
L.geoJson(convexHull).addTo(map);

// Example: hexgrid
var bbox = [-10,30,75,60];
var cellWidth = 500;
var units = 'miles';
var hexgrid = turf.hexGrid(bbox, cellWidth, units);
L.geoJson(hexgrid).addTo(map);


// Example: Isolines
/*
var points = turf.random('point', 100000, {
  bbox: [-10,30,75,60]
});
*/

for (var i = 0; i < geodata.features.length; i++) {
  geodata.features[i].properties.z = Math.random() * 10;
}
var breaks = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var isolined = turf.isolines(geodata, 'z', 15, breaks);
L.geoJson(isolined).addTo(map);


// Previous code
L.marker([50, 10]).addTo(map);

L.tileLayer( 'http://a.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'OpenStreetMap',
}).addTo( map );


var geojsonMarkerOptions = {
    radius: 5,
    fillColor: "#ff7800",
    color: "#000",
    weight: 1,
    opacity: 1,
    fillOpacity: 0.8
};

L.geoJson(geodata, {
    pointToLayer: function (feature, latlng) {
        return L.circleMarker(latlng, geojsonMarkerOptions);
    }
}).addTo(map);